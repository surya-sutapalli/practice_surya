package com.athi.TEST3_AthiLakshmi;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PatientDao {
    public static void main(String[] args) {

        Configuration cf=new Configuration();
        cf.configure("hibernate.cfg.xml");
        SessionFactory s=cf.buildSessionFactory();
        Session ses=s.openSession();
        Transaction t=ses.beginTransaction();
        Patient p = new Patient();
        System.out.println("Enter option 1/2/3");
        Scanner scan = new Scanner(System.in);
        int option = scan.nextInt();
        if(option==1)
        {
            p.setPatientID(101);
            p.setPatientName("renu");
            p.setPatientDisease("Thyroid");
            ses.persist(p);

        }
        if(option==2)
        {
            Object o=ses.get(Patient.class,new Integer(104));
            Patient p1=(Patient)o;
            p1.setPatientDisease("corno");
            ses.update(p1);
        }
        if(option==3)
        {
            Object o=ses.get(Patient.class,new Integer(102));
            Patient p2=(Patient)o;
            ses.delete(p2);
        }

        t.commit();
        ses.close();
        s.close();

    }

}


