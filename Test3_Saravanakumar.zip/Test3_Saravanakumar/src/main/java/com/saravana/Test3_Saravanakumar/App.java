package com.saravana.Test3_Saravanakumar;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
    	 //Object o=ctx.getBean("obj");
    	 //Person ob = (Person)o;
    	 Object o=ctx.getBean("obj1");
    	 Person ob = (Person)o;
    	 ob.displayInfo();
    }
}
