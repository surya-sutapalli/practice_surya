package com.saravana.Test3_Saravanakumar;

public class Address {
	String addressline1,city,state,country;
	Address(String addressline1,String city,String state,String country)
	{
		this.addressline1=addressline1;
		this.city=city;
		this.state=state;
		this.country=country;
	}

	public String getAddressline1() {
		return addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	public String toString(){  
	    return addressline1+"|||"+city+"|||"+state+"|||"+country;  
	} 
}
