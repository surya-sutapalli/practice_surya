package com.sha.TEST3_Kalaivani;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
	public void recordinsert(Session s,Transaction t,Patient obj)
	{
	    obj.setPatientId(1);
	    obj.setPatientName("Sharmila");//insert
	    obj.setPatientDisease("Ulcer");
	    obj.setPatientId(2);
	    obj.setPatientName("Kalai");//insert
	    obj.setPatientDisease("Stomach pain");
	    obj.setPatientId(3);
	    obj.setPatientName("Jimin");//insert
	    obj.setPatientDisease("Fracture");
	    obj.setPatientId(4);
	    obj.setPatientName("Anirudh");
	    obj.setPatientDisease("Thyroid");
	    obj.setPatientId(5);
	    obj.setPatientName("Shri");
	    obj.setPatientDisease("HeartAttack");
	    s.save(obj);
		t.commit();

	}
	public void update(Session s,Transaction t,Patient obj)
	{
		obj.setPatientName("Ani");
		obj.setPatientDisease("EyeProblem");
		obj.setPatientId(5);
		s.update(obj);
		t.commit();
	}
	public void delete(Session s,Transaction t,Patient obj)
	{
		Object o=s.get(Patient.class,new Integer(0));
		Patient p=(Patient)o;
		s.delete(p);
		t.commit();
	}
	
	public void display(Session s,Patient obj,int pid){


		Object o=s.get(Patient.class,new Integer(pid));
		Patient p=(Patient)o;
		try
		{ System.out.println(p.getPatientId()+"---"+p.getPatientName()+"--- "+p.getPatientDisease());

		}
		catch(NullPointerException e)
		{
			System.out.println("No Patient Found");
		}

	}
	public static void main( String[] args )
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		App a=new App();
		Patient obj=new Patient();
		//a.recordinsert(s,t,obj);
		//a.update(s,t,obj);
		a.delete(s, t, obj);
		
		Scanner sc= new Scanner(System.in);

		while(true) 
		{
			System.out.println("Enter Patient Id : ");
			int pid=sc.nextInt();
			a.display(s,obj,pid);
			System.out.println("Do you want to continue? y/n");
			String op=sc.next();
			if(op.equalsIgnoreCase("y"))
			{continue;}
			else
			{System.out.println("Terminated Successfully");
			break;}
		}  

		sc.close();
		s.close();
		sf.close();
	}
}



