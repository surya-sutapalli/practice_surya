import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testquestion4',
  templateUrl: './testquestion4.component.html',
  styleUrls: ['./testquestion4.component.css']
})
export class Testquestion4Component  {

 character: string ='c';
  status:boolean= false;
  message: String='It is a Vowel';
  message1: String='It is a consonent';

  vowelOrConsonant()
    {
        if (this.character == 'a' || this.character == 'e' || this.character == 'i' || this.character == 'o' || this.character == 'u')
           return this.status=true;
        else
            return this.status=false;
    }

}