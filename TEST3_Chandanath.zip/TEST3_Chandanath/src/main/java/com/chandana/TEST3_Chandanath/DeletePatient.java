package com.chandana.TEST3_Chandanath;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.chandana.TEST3_Chandanath.Patient;

public class DeletePatient {
	public static void main(String[] args) {
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory f=cfg.buildSessionFactory();
		Session s =f.openSession();
		Transaction t=s.beginTransaction();
		Object o=s.get(Patient.class,new Integer(6));
		Patient p=(Patient)o;
		s.delete(p);
		t.commit();
		s.close();
		f.close();
	}


}
