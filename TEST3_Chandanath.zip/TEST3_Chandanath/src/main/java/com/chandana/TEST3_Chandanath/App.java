package com.chandana.TEST3_Chandanath;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.chandana.TEST3_Chandanath.Patient;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory f=cfg.buildSessionFactory();
		Session s =f.openSession();
		Transaction t=s.beginTransaction();
		Patient p=new Patient();
		p.setPatientID(1);
		p.setPatientName("Chandana");
		p.setPatientDisease("Coronavirus");
		s.save(p);
		t.commit();
		s.close();
		f.close();
    }
}
