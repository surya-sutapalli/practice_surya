package com.chandana.TEST3_Chandanath;
import java.util.Scanner;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.chandana.TEST3_Chandanath.Patient;

public class SelectPatient {
	public static void main(String[] args) {

		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory f=cfg.buildSessionFactory();
		Session s =f.openSession();
		Transaction t=s.beginTransaction();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Patient Id");
		int id=sc.nextInt();
		Object o=s.load(Patient.class,new Integer(id));
		Patient p=(Patient)o;
		try {
			if(id==p.getPatientID()) {
				System.out.println(p.getPatientID()+"-->"+p.getPatientName()+"-->"+p.getPatientDisease());
			}
		}
		catch(ObjectNotFoundException obj) {
			System.out.println("Patient Id is not found");
		}
		t.commit();
		s.close();
		f.close();
	}


}
