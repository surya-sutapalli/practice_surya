package harsh;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class SumOfNaturalNumbers extends TagSupport {

	private int start;

	public void setStart(int start) {
		this.start = start;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	private int end;
	private int sum = 0;

	public void setSum(int sum) {
		this.sum = sum;
	}

	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();

		try {
			for (int i = this.start; i <= this.end; i++) {
				sum = this.sum + i;

			}
			out.println(this.sum);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return SKIP_BODY;
	}
}
