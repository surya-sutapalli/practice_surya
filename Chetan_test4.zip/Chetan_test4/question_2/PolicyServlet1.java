

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PolicyServlet1 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   try {
			 
			  ServletContext ctx=getServletContext();
			   String d=ctx.getInitParameter("driver");
			String pID=request.getParameter("policyId");
			String pName=request.getParameter("policyName");
			String pAmount=request.getParameter("policyAmount");
			String pDuration=request.getParameter("policyDuration");
		
			
			 Class.forName("com.mysql.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/test_4","root","chetan15033");
			PreparedStatement pst=c.prepareStatement("insert into policy values(?,?,?,?)");
			pst.setInt(1,Integer.parseInt(pID));
			pst.setString(2, pName);
			pst.setInt(3,Integer.parseInt(pAmount));
			pst.setInt(4,Integer.parseInt(pDuration));
		
			pst.execute();
			

		      response.getWriter().println("<html><head><link rel=\"stylesheet\"  href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\"></head><body>"
		          + "<p class=\"text-info text-center text-capitalize\">Record inserted successfully</p><br><br><br>");
		      response.getWriter().println("<a type=\"button\" class=\"btn-success btn-lg btn-block\" href=http://localhost:8080/AssignmentWeb/studentinsert.html>Back</a>");
		      response.getWriter().println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>\r\n"
		          + "  <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\r\n"
		          + "  <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js\"></script></body></html>");

			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		}
	}
	
	

	


