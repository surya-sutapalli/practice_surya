package com.aditi.Test3;

public class Patient {
    int patientID;
    String patientName;
    String patientDisease;

    Patient(int patientID, String patientName , String patientDisease)
    {
        this.patientID=patientID;
        this.patientName=patientName;
        this.patientDisease=patientDisease;
    }
}
