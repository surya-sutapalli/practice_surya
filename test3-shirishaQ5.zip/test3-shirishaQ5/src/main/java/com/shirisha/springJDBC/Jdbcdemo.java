package com.shirisha.springJDBC;
import java.util.Iterator;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class Jdbcdemo {
  JdbcTemplate template;
  public JdbcTemplate getTemplate() {
    return template;
  }

  public void setTemplate(JdbcTemplate template) {
    this.template = template;
  }
  public void CreateTable()
  {
    template.execute("create table patient(patientid int,patientname varchar(20),patientDisease varchar(20))");
  }
  public void insertRecord() 
  {
    template.update("insert into patient values(101,'basha','fever')");
    template.update("insert into patient values(102,'bavana','skin allergy')");
    template.update("insert into patient values(103,'balu','heart')");
    template.update("insert into patient values(104,'basu','cancer')");
    template.update("insert into patient values(105,'brinda','cold')");
    

}  public void updateRecord()
  {
    template.update("update movie set patientid='111',patientDisease='corona' where patientid=102");
  }
  public void deleteRecord()
  {
    template.update("delete from patient where patientid=105");
  
}
  public void selectRecord()
  {
    List l=template.queryForList("select* from patient");
    Iterator i=l.iterator();
    while(i.hasNext())
    {
      System.out.println(i.next());
    }
    
  }
}
	