package com.shirisha.springJDBC;
import java.util.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class App 
{
	public static void main(String[] args)
	{
		ApplicationContext cxt=new ClassPathXmlApplicationContext("config.xml");
		Object o=cxt.getBean("demo");
		Jdbcdemo j=(Jdbcdemo) o;
		System.out.println("enter your choice:");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		while(true)
		{
			if(choice==1) {
				j.CreateTable();
				break;}
			else if(choice==2) {
				j.insertRecord();
				break;
			}
			else if(choice==3)
			{
				j.deleteRecord();
				break;
			}
			else if(choice==4)
			{
				j.updateRecord();
				break;
			}
			else if(choice==5)
			{
				j.selectRecord();
				break;

			}
			else
				System.out.println("INVALID CHOICE");
				break;
		}
	}
}
