import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vowels',
  templateUrl: './vowels.component.html',
  styleUrls: ['./vowels.component.css']
})
export class VowelsComponent {
public name:string="";
  display(name:string) {
    this.name = name;
  }
}
