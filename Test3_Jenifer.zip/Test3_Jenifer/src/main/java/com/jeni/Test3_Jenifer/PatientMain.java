package com.jeni.Test3_Jenifer;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class PatientMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Configuration cf=new Configuration();
	     cf.configure("hibernate.cfg.xml");
	     SessionFactory s=cf.buildSessionFactory();
	     Session ses=s.openSession();
	     Transaction t=ses.beginTransaction();
	        Patient1 p=new Patient1();
	       // PatientRecord r=new PatientRecord();
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Enter your choice");
	        int n=sc.nextInt();
	        if(n==1)
	        {
	        	p.setPatientId(106);
	        	p.setPatientName("bigboss");
	        	p.setPatientDisease("typhoid");
	        	  ses.save(p);
	  	        t.commit();
	  	        ses.close();
	  	        s.close();
	        }
	        else if(n==2)
	        {
	        	 Object o=ses.get(Patient1.class,new Integer(102));
	 	        Patient1 pq=(Patient1)o;
	 	       pq.setPatientName("vikas");
	        	//p.setPatientDisease("tuberculosis");
	 	       ses.update(pq);
	  	        t.commit();
	  	        ses.close();
	  	        s.close();
	        }
	        else if(n==3)
	        {
	        	Object o=ses.get(Patient1.class,new Integer(106));
	 	        Patient1 pq=(Patient1)o;
	 	       ses.delete(pq);
	  	        t.commit();
	  	        ses.close();
	  	        s.close();
	        }
	        else
	        {
	        	System.out.println("invalid choice");
	        }

	}

}
