import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertStudentServlet
 */
public class Question2Servlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   try {
		  ServletContext ctx=getServletContext();
		   String d=ctx.getInitParameter("driver");
		String pID=request.getParameter("policyId");
		String pName=request.getParameter("policyName");
		String pAmount=request.getParameter("policyAmount");
		String pDuration=request.getParameter("policyDuration");
	
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/test4","root","welcome");
		PreparedStatement pst=c.prepareStatement("insert into policy values(?,?,?,?)");
		pst.setInt(1,Integer.parseInt(pID));
		pst.setString(2, pName);
		pst.setInt(3,Integer.parseInt(pAmount));
		pst.setInt(4,Integer.parseInt(pDuration));
	
		pst.execute();
		
		
		
		
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	}
}

