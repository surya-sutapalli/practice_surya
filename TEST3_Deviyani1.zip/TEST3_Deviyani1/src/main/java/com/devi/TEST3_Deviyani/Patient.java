package com.devi.TEST3_Deviyani;

public class Patient 
{
	int patientId;
	String patientName;
	String patientDisease;
	Patient(int patientId, String patientName, String patientDisease)
	{
		this.patientId=patientId;
		this.patientName=patientName;
		this.patientDisease=patientDisease;
	}
}
