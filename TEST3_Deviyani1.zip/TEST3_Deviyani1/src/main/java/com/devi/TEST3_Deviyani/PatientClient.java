package com.devi.TEST3_Deviyani;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class PatientClient 
{
	public static void main(String[] args) {
	ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
	Object o = ctx.getBean("obj1");
	Patient pt =(Patient)o;
	System.out.println(pt.patientId+"----"+pt.patientName+"----"+pt.patientDisease);
	}
}
