package shriram;

import java.util.Calendar;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class TagVowelHandler extends TagSupport {
  private String word;

  public void setWord(String word) {
    this.word = word;
  }

  public int doStartTag() throws JspException{
    JspWriter out=pageContext.getOut();
    try {
      out.print("Vowels are : ");
      for(int i=0; i<word.length();i++)   {
        if(word.charAt(i) == 'a'|| word.charAt(i) == 'e'|| word.charAt(i) == 'i' || word.charAt(i) == 'o' || word.charAt(i) == 'u' || word.charAt(i) == 'A'|| word.charAt(i) == 'E'|| word.charAt(i) == 'I' || word.charAt(i) == 'O' || word.charAt(i) == 'U') {
          out.println(word.charAt(i));
      }
      
    }
    }
    catch(Exception e) {
      System.out.println(e);
    }
    return SKIP_BODY;
  }

}
