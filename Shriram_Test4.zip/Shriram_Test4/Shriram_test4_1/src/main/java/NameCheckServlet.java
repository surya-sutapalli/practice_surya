

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class NameCheckServlet extends HttpServlet {
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    RequestDispatcher rd=null;
    String str=request.getParameter("usr");
 
    char[] ch = str.toCharArray();
    int u=0,l=0,d=0,s=0;
 // HttpSession hs=request.getSession();
    for(char c:ch) {
      if(Character.isUpperCase(c))
      {
        u++;
      }
      if(Character.isLowerCase(c))
      {
        l++;
      }
      if(Character.isDigit(c))
      {
        d++;
      }
      if(!Character.isLetterOrDigit(c))
      {
        s++;
      }
      
    }
    response.getWriter().println("<html><body bgcolor=lightblue>");
    response.getWriter().println("<h2> No of Uppercase: "+u+"</h2><br>");
    response.getWriter().println("<h2> No of Lowercase: "+l+"</h2><br>");
    response.getWriter().println("<h2> No of Digits: "+d+"<h2><br>");
    response.getWriter().println("<h2> No of Special characters: "+s+"<h2><br>");
    response.getWriter().println("<a href=http://localhost:8080/Shriram_test4_1/Login.html >Back</a>");
    response.getWriter().println("</body></html>");
    
 }

}
