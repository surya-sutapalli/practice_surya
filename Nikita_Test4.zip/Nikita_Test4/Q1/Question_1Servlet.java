import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Question_1Servlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
			    
			    	String str = request.getParameter("tf1");
			    	
			        int upper = 0, lower = 0, number = 0, special = 0;
			 
			        for(int i = 0; i < str.length(); i++)
			        {
			            char ch = str.charAt(i);
			            if (ch >= 'A' && ch <= 'Z')
			                upper++;
			            else if (ch >= 'a' && ch <= 'z')
			                lower++;
			            else if (ch >= '0' && ch <= '9')
			                number++;
			            else
			                special++;
			        }
			        response.getWriter().println("Lower case letters : " + lower);
			        response.getWriter().println("Upper case letters : " + upper);
			        response.getWriter().println("Number : " + number);
			        response.getWriter().println("Special characters : " + special);
			    }
			}

	
		


