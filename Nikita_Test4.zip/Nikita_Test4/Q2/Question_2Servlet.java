import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Question_2Servlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException
	{
		try {
		String pId = request.getParameter("pid");
		String pname = request.getParameter("pname");
		String pamount = request.getParameter("pamount");
		String pDuration = request.getParameter("pduration");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/policy","root","Nikita@99");
		PreparedStatement pst=c.prepareStatement("insert into stud values(?,?,?,?,?)");
		pst.setInt(1,Integer.parseInt(pId));
		pst.setString(2,pname);
		pst.setString(3, pamount);
		pst.setString(4, pDuration);
		pst.execute();

	}
		catch(Exception e) {
			e.printStackTrace();
			
		}

}
}