import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class StringServlet extends HttpServlet {
  
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String str = request.getParameter("tf1");
   
    int upper = 0, lower = 0,digit=0,special=0;
    int len = str.length();
    for(int i = 0; i < len; i++)
    {
      if(Character.isUpperCase(str.charAt(i)))
        upper++;
       
      else if(Character.isLowerCase(str.charAt(i)))
        lower++;
      else if(Character.isDigit(str.charAt(i)))
          digit++;
      else if(!Character.isLetterOrDigit(str.charAt(i)))
          special++;
    }
    response.getWriter().println("<h3>Enter a String:"+str+"</h3>");

    response.getWriter().println("<br>");

    response.getWriter().println("<table border=2 bgcolor=orange align=left>");
    response.getWriter().println("<style>\r\n"
            + "body{\r\n"
            + "background-image:url(\"C:\\\\Users\\\\ELCOT\\\\Desktop\\\\HTML\\\\B3.jpg\");\r\n"
            + "background-repeat:no-repeat;\r\n"
            + "background-attachment: fixed;\r\n"
            + "background-size: 100% 100%;\r\n"
            + "\r\n"
            + "}\r\n"
            + "</style>");

    
    response.getWriter().println("<thead><th>String Name</th><th>Count</th>");
    response.getWriter().println("<tbody>");
   // response.getWriter().println("<td>"+rs.getInt(1)+"</td>");
    
    response.getWriter().println("<td>No.of Uppercase</td> " + "<td>"+upper+"</td>");

    response.getWriter().println("<tr><td>No.of Lowercase</td> " + "<td>"+lower+"</td></tr>");
    response.getWriter().println("<tr><td>No.of Digit</td> " + "<td>"+digit+"</td><tr>");
    response.getWriter().println("<tr><td>No.of Special Character</td> " + "<td>"+special+"</td></tr>");
    
    response.getWriter().println("</tbody>");
    response.getWriter().println("</table>");

   

  }

}