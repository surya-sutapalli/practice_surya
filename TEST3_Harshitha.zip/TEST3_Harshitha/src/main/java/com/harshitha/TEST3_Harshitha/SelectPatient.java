package com.harshitha.TEST3_Harshitha;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class SelectPatient {
	public static void main(String[] args) {
		int idnum=0;
		while(true)
		{
		System.out.println("\nPlease enter the patientId you want to display the record:");
	
		try {
		Scanner sc=new Scanner(System.in);
		 idnum=sc.nextInt();
		 break;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("please enter integer value");
			continue;
		}
		
		}
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory f= cfg.buildSessionFactory();
		Session s=f.openSession();
		Transaction t=s.beginTransaction();
		try
		{
		Object o=s.load(Patient1.class,new Integer(idnum));
		Patient1 p= (Patient1)o;
		System.out.println(p.getId()+"--"+p.getPatientName()+"--"+p.getPatientDisease());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("No Patient found");
		}
		
		s.close();
		f.close();

}
}