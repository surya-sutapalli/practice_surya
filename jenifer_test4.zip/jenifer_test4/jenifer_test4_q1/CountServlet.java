

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CountServlet
 */
public class CountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s = request.getParameter("tf1");
		int u=0,l=0,d=0,s1=0;
		for(int i=0;i<s.length();i++)
		{
			
		if(Character.isUpperCase(s.charAt(i)))
		{
		 u++;	
		}
		else if(Character.isLowerCase(s.charAt(i)))
		{
			l++;
		}
		else if(Character.isDigit(s.charAt(i)))
		{
			d++;
		}
		else
		{
			s1++;
		}
	}
		
		
		response.getWriter().println("The number of uppercase letter is "+u+"<br>");
		response.getWriter().println("The number of lowercase letter is "+l+"<br>");
		response.getWriter().println("The number of digit is "+d+"<br>");
		response.getWriter().println("The number of special character is "+s1+"<br>");
		
		



}
}
