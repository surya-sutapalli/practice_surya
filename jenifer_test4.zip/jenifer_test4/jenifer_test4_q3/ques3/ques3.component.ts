import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ques3',
  templateUrl: './ques3.component.html',
  styleUrls: ['./ques3.component.css']
})
export class Ques3Component  {
  var1:string="";
  display(var1:any)
  {
    this.var1=var1;
  }




}
