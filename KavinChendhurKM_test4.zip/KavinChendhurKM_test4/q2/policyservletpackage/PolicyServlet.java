package policyservletpackage;



import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import policypojopackage.PolicyPojoClass;
import org.hibernate.annotations.common.*;


public class PolicyServlet extends HttpServlet {
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		   Configuration cfg=new Configuration();
	       cfg.configure("hibernate.cfg.xml");
	       SessionFactory sf=cfg.buildSessionFactory();
	       Session s=sf.openSession();
	       Transaction t=s.beginTransaction();
	      
	       PolicyPojoClass cc=new PolicyPojoClass();
	       cc.setPolicyId(Integer.parseInt(request.getParameter("pid")));
	       cc.setPolicyName(request.getParameter("pname"));
	       cc.setPolicyAmount(Integer.parseInt(request.getParameter("pamount")));
	       cc.setDuration(Integer.parseInt(request.getParameter("pduration")));
	       
        s.persist(cc);
	       
	       t.commit();
	       s.close();
	       sf.close();
		
	    response.getWriter().println("<html>");
	    response.getWriter().println("<head>");
	    response.getWriter().println("<style>");
	    response.getWriter().println("div {\r\n"
	    		+ "  border-radius: 5px;\r\n"
	    		+ "  background-color: #f2f2f2;\r\n"
	    		+ "  padding: 20px;\r\n"+"font-size:150%;"
	    		+ "}");
	    response.getWriter().println("</style>");
	    response.getWriter().println("</head>");
	    
		response.getWriter().println("<div>Record Inserted Successfully!</div>");
		response.getWriter().println("</html>");
	}

	

}
