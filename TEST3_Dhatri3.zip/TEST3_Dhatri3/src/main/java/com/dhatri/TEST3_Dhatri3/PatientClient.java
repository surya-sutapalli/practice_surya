package com.dhatri.TEST3_Dhatri3;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.dhatri.TEST3_Dhatri3.Patient;

public class PatientClient
{
    public static void main( String[] args )
    {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();
        Session session = factory.openSession();
        Transaction t = session.beginTransaction();
        Patient p = new Patient();
        System.out.println("Enter the operation\n 1.For inserting\n 2.For updating\n 3.For deleting ");
        Scanner sc = new Scanner(System.in);
        int option = sc.nextInt();
        if(option==1)
        {
        p.setPatientID(8);
        p.setPatientName("anushree");
        p.setPatientDisease("diabetes");
        session.save(p);

        }
        if(option==2)
        {
        Object o=session.load(Patient.class,new Integer(6));
        Patient p1 =(Patient)o;
        p1.setPatientDisease("fever");
        session.update(p1);
        
        }
        if(option==3)
        {
        Object o=session.load(Patient.class,new Integer(8));
               Patient p2=(Patient)o;
               session.delete(p2);
        }
        
        t.commit();
        session.close();
        factory.close();
        
    }
}
