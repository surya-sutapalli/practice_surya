import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ValidateServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		    String string=request.getParameter("string1");
		    char[] character = string.toCharArray();
		    int upper=0,lower=0,digit=0,special=0;
		    for(char c:character) {
		      if(Character.isUpperCase(c)) {
		    	  upper++;
		      }
		      if(Character.isLowerCase(c)) {
		    	  lower++;
		      }
		      if(Character.isDigit(c)) {
		    	  digit++;
		      }
		      if(!Character.isLetterOrDigit(c)) {
		    	  special++;
		      }
		    }
		    response.getWriter().println("No of Uppercase: "+upper+"<br>");
		    response.getWriter().println("No of Lowercase: "+lower+"<br>");
		    response.getWriter().println("No of Digits: "+digit+"<br>");
		    response.getWriter().println("No of Special characters: "+special+"<br>");
		    
		    
		 }
	}