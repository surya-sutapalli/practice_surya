package com.kavin.Test3_part2;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class PatientDao 
{
	
	HibernateTemplate template;
	
	
	public void setTemplate(HibernateTemplate template) {
		this.template=template;
	}

	
	public void savePatient(Patient e) {
		
		template.save(e);
		
		
	}
	public void updatePatientt(Patient e) {
		template.update(e);
	}
	public void deletePatient(Patient e) {
		template.delete(e);
	}
	
	public List<Patient> getPatients(){
		List<Patient> list=new ArrayList<Patient>();
		list=template.loadAll(Patient.class);
		return list;
	}
}