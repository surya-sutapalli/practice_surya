package com.kavin.Test3_part2;

import java.util.*;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


public class App {
	static Scanner sc=new Scanner(System.in);
	public void insert(PatientDao dao,Patient pt)
	{
		System.out.println("Enter Patient Id:");
		pt.setPatientId(sc.nextInt());
		System.out.println("Enter Patient Name:");
		pt.setPatientName(sc.next());
		System.out.println("Enter Patient Disease:");
		pt.setPatientDisease(sc.next());
		dao.savePatient(pt);	
	}
	public void update(PatientDao dao,Patient pt)
	{
		System.out.println("Enter Patient Id to update:");
		pt.setPatientId(sc.nextInt());
		System.out.println("Enter Patient Name to update:");
		pt.setPatientName(sc.next()); 
		System.out.println("Enter Patient Disease to update:");
		pt.setPatientDisease(sc.next());
		dao.updatePatientt(pt);
	}
	public void delete(PatientDao dao,Patient pt)
	{
		System.out.println("Enter Patient Id to delete:");
		pt.setPatientId(sc.nextInt());
        dao.deletePatient(pt); 
	}
	public void show(PatientDao dao)
	{
		List<Patient> l=dao.getPatients();
		System.out.println();
		Iterator i=l.iterator();
		while(i.hasNext()) {
			Patient s=(Patient) i.next();
			System.out.println(s.getPatientId()+"----"+s.getPatientName()+"----"+s.getPatientDisease()); 
		}
	}
	public static void main(String[] args) {
		App a=new App();

		Resource r=new ClassPathResource("applicationContext.xml");
		BeanFactory factory=new XmlBeanFactory(r);

		PatientDao dao=(PatientDao)factory.getBean("p");
		Patient pt=new Patient();

		System.out.println("Enter 1 to addPatient \nEnter 2 to updatePatientDetails \nEnter 3 to deletePatient Record \nEnter 4 to view Patients");
		int option=sc.nextInt();
		switch(option) {
		case 1:
			a.insert(dao, pt);
			break;
		case 2:
			a.update(dao, pt);	
			break;
		case 3:
			a.delete(dao, pt);
			break;
		case 4:
			a.show(dao);
			break;
		}     
	}	
}


