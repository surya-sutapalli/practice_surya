package com.gaurav.test3_gaurav1;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
        Object obj= ctx.getBean("patient");
        Patient p =(Patient)obj;
        System.out.println("PatientID ="+p.patientId+"||"+"PatientName ="+p.patientName+"||"+"PatientDisease ="+p.patientDisease);
        
    }
}