package com.madhan.TEST3_Dhibiya;

public class Patient {

	int PatientId;
	String PatientName;
	String PatientDisease;
	
	public int getPatientId() {
		return PatientId;
	}
	public void setPatientId(int patientId) {
		this.PatientId = patientId;
	}
	public String getPatientName() {
		return PatientName;
	}
	public void setPatientName(String patientName) {
		this.PatientName = patientName;
	}
	public String getPatientDisease() {
		return PatientDisease;
	}
	public void setPatientDisease(String patientDisease) {
		this.PatientDisease = patientDisease;
	}
	
}
