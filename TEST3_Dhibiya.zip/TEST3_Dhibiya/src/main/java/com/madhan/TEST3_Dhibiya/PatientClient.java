package com.madhan.TEST3_Dhibiya;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PatientClient {
	Scanner sc = new Scanner(System.in);

	public void getDetails(Session s, Transaction t, Patient patient)
	{
		patient.setPatientId(1001);
		patient.setPatientName("Amutha");
		patient.setPatientDisease("ViralFever");
		//patient.setPatientId(1002);
		//patient.setPatientName("Kanitha");
		//patient.setPatientDisease("Cholera");
		//patient.setPatientId(1003);
		//patient.setPatientName("Preethi");
		//patient.setPatientDisease("Chikungunya");
		//patient.setPatientId(1004);
		//patient.setPatientName("Ramu");
		//patient.setPatientDisease("CommonCold");
		//patient.setPatientId(1005);
		//patient.setPatientName("Dharun");
		//patient.setPatientDisease("Diabetes");
	}

	public void findRecord(Session s, Patient patient)
	{
		
		while(true)
		{
			System.out.println("Enter the PatientId : ");
			int id = sc.nextInt();
			Object o = s.get(Patient.class, new Integer(id));
			Patient p = (Patient) o;
			try
			{
				System.out.println(p.getPatientId() + "-->" + p.getPatientName() + "-->" + p.getPatientDisease());
			}
			catch(NullPointerException e)
			{
				System.out.println("Record Not Found");
			}
			System.out.println("Do You Want to Continue : ");
			String str = sc.next();
			if(str.equalsIgnoreCase("y"))
				continue;
			else
				break;	
		}
	}

	public void updateRecord(Session session,Transaction t)
	{
		System.out.println("Enter the PatientId to update the record : ");
		int id = sc.nextInt();
		Object o=session.get(Patient.class,new Integer(id));
		Patient pat=(Patient)o;
		pat.setPatientName("kavi");
		pat.setPatientDisease("cancer");
		session.update(pat);
		t.commit();
		System.out.println("UPDATED SUCESSFULLY");
	}

	public void deleteRecord(Session session,Transaction t)
	{
		System.out.println("Enter the PatientId to delete the record : ");
		int id = sc.nextInt();
		Object o=session.get(Patient.class,new Integer(id));
		Patient pat=(Patient)o;
		session.delete(pat);
		t.commit();
		System.out.println("DELETED SUCCESSFULLY");
	}

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("Hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		Patient patient = new Patient();
		PatientClient p = new PatientClient();
		p.getDetails(s,t,patient);
		p.findRecord(s,patient);
		p.updateRecord(s,t);
		p.deleteRecord(s,t);
		s.save(patient);
		t.commit();
		s.close();
		sf.close();
	}
}
