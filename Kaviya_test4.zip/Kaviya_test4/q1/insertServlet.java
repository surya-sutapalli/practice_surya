

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class insertServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().println("<div align=right> <a href=http://localhost:8080/StudentAssignment/LogoutServlet1> Sign-Out </a> </div>");
		ServletContext l=getServletContext();
		String st=l.getInitParameter("driver");
		String id=request.getParameter("tf1");
		String name=request.getParameter("tf2");
		String amount=request.getParameter("tf3");
		String duration=request.getParameter("ti");
		try
		{
        Class.forName(st);
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "root");
		PreparedStatement pst=c.prepareStatement("insert into policy values(?,?,?,?)");
		pst.setInt(1, Integer.parseInt(id));
		pst.setString(2, name);
		pst.setString(3, amount);
		pst.setString(4, duration);
		pst.execute();
		response.getWriter().println("<style>\r\n"
				+ "body{\r\n"
				+ "background-image:url(\"D:\\\\login.jpeg\");\r\n"
				+ "background-repeat:no-repeat;\r\n"
				+ "background-attachment: fixed;\r\n"
				+ "background-size: 100% 100%;\r\n"
				+ "\r\n"
				+ "}\r\n"
				+ "</style>"
		
				
				+"<center><b><h1>"+"inserted sucessfuly :-) !!!"+"<h1></center></b>"+"</body>");
		}
		catch(Exception Ee)
		{
			response.getWriter().println();
		}
	}


}
