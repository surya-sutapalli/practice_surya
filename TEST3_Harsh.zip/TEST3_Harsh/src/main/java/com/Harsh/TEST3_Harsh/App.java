package com.Harsh.TEST3_Harsh;

import java.util.Scanner;

public class App {
	static final Scanner scan = new Scanner(System.in);
	static final Patient obj = new Patient();

	public static void main(String[] args) {
		System.out.println("Welcome To Patient Portal What You Wanna Do Today ??" + "\n");
		System.out.println("Insert Records");
		System.out.println("Update Records");
		System.out.println("Delete Records");
		System.out.println("Quit");
		int option = scan.nextInt();
		if (option == 1) {
			InsertRecords.insertRecords();
		} else if (option == 2) {
			UpdateRecords.update();
		} else if (option == 3) {
			DeleteRecords.delete();
		} else if (option == 4) {
			System.out.println("Thank You! Get Well Soon....");
			System.exit(0);
		} else {
			System.out.println("Please Enter The Valid Option");
			App.main(null);
		}
	}
}
