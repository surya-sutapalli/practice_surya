package com.Harsh.TEST3_Harsh;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateRecords {
	final static Scanner scan = new Scanner(System.in);

	public static void update() {
		System.out.println("Enter The ID you Want To Update : ");
		int id = scan.nextInt();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory f = cfg.buildSessionFactory();
		Session s = f.openSession();
		Transaction t = s.beginTransaction();
		Object o = s.get(Patient.class, new Integer(id));
		Patient p = (Patient) o;
		System.out.println("Enter Updated Name : ");
		String name = scan.next();
		p.setPatientName(name);
		System.out.println("Enter Disease: ");
		String disease = scan.next();
		p.setPatientDisease(disease);
		s.update(p);
		t.commit();
		s.close();
		f.close();
		System.out.println("Updated Sucessfully!");
		App.main(null);
	}
}
