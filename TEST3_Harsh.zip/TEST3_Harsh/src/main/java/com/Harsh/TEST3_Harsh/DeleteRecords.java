package com.Harsh.TEST3_Harsh;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DeleteRecords {
	static final Scanner scan = new Scanner(System.in);
	static final Patient obj = new Patient();

	public static void delete() {
		System.out.println("Enter Patient ID You Want To Delete : ");
		int id = scan.nextInt();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		Object o = s.get(Patient.class, new Integer(id));
		Patient p = (Patient) o;
		s.delete(p);
		t.commit();
		s.close();
		sf.close();
		System.out.println("Deletion of record with id number " + id + "is Successful!");
		App.main(null);
	}
}
