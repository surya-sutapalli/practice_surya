package com.manisha.Test3_Manisha3;

public class Patient {
    int PatientId;
    String PatientName;
    String PatientDisease;
    public int getPatientId() {
        return PatientId;
    }
    public void setPatientId(int patientId) {
        PatientId = patientId;
    }
    public String getPatientName() {
        return PatientName;
    }
    public void setPatientName(String patientName) {
        PatientName = patientName;
    }
    public String getPatientDisease() {
        return PatientDisease;
    }
    public void setPatientDisease(String patientDisease) {
        PatientDisease = patientDisease;
    }

}