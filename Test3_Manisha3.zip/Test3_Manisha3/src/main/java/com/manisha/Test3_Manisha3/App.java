package com.manisha.Test3_Manisha3;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory Fac = cfg.buildSessionFactory();
        Session session = Fac.openSession();
        Transaction transac = session.beginTransaction();
        
        
        Patient p = new Patient();
        System.out.println("Enter the operation:1/2/3");
        Scanner sc = new Scanner(System.in);
        int op = sc.nextInt();
        if(op==1)
        {
        p.setPatientId(105);
        p.setPatientName("Ramya");
        p.setPatientDisease("Cholera");
        
        session.persist(p);

        }
        if(op==2)
        {
        Object o=session.get(Patient.class,new Integer(105));
        Patient p1 =(Patient)o;
        p1.setPatientDisease("Dengue");
        session.update(p1);
        }
        if(op==3)
        {
        Object o=session.get(Patient.class,new Integer(101));
               Patient p3=(Patient)o;
               session.delete(p3);
        }
        session.save(p);
        transac.commit();
        session.close();
        Fac.close();
        
    }
}