package com.sindhu.TEST3_Sindhu;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
public class PatientOps {
	JdbcTemplate template;
	Patient p = new Patient();
	Scanner sc = new Scanner(System.in);
	public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	public void createTable() {
		template.execute("create table patient(patientID int AUTO_INCREMENT, patientName varchar(40), patientDisease varchar(60), PRIMARY KEY(patientID))");
	}
	public void insertPat() {
		System.out.println("Enter the patient name:");
		String name=sc.nextLine();
		System.out.println("Enter the patient disease:");
		String disease=sc.nextLine();
		template.update("insert into patient(patientName,patientDisease) values('"+name+"','"+disease+"')");
		System.out.println("Record Successfully inserted into our records. Redirecting you back to menu.");
		p.menuOptions();
	}
	public void updatePat() {
		Scanner sc = new Scanner(System.in);
		int pid=0;
		try{
			System.out.println("Enter the patient ID:");
			pid=sc.nextInt();
		} catch (InputMismatchException ie) {
			System.out.println("WARNING: Please enter valid choice!");
			updatePat();
		}
		List l = template.queryForList("select * from patient where patientID="+pid);
		Iterator i = l.iterator();
		int flag=0;
		while(i.hasNext()) {
			flag=1;
			break;
		}
		if(flag==0) {
			System.out.println("INVALID: You're trying to update a record that is not in the database.");	
		}
		if(flag==1) {
			System.out.println("Enter the patient disease:");
			String disease=sc.next();
			template.update("update patient set patientDisease='"+disease+"' where patientID="+pid);
			System.out.println("Record Successfully updated. Redirecting you back to menu.");
		}
		p.menuOptions();
	}
	public void deletePat() {
		Scanner sc = new Scanner(System.in);
		int pid=0;
		try{
			System.out.println("Enter the patient ID:");
			pid=sc.nextInt();
		} catch (InputMismatchException ie) {
			System.out.println("WARNING: Please enter valid choice!");
			deletePat();
		}
		List l = template.queryForList("select * from patient where patientID="+pid);
		Iterator i = l.iterator();
		int flag=0;
		while(i.hasNext()) {
			flag=1;
			break;
		}
		if(flag==0) {
			System.out.println("INVALID: You're trying to delete a record that is not in the database.");	
		}
		if(flag==1) {
			template.update("delete from patient where patientID="+pid);
			System.out.println("Record Successfully deleted. Redirecting you back to menu.");
		}
		p.menuOptions();
	}
	public void selectAll() {
		List l = template.queryForList("select * from patient");
		Iterator i = l.iterator();
		int flag=0;
		while(i.hasNext()) {
			flag=1;
			System.out.println(i.next());
		}
		if(flag==0) {
			System.out.println("No records found.");
		}
		p.menuOptions();
	}
}