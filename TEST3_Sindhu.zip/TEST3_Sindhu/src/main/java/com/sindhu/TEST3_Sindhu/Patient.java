package com.sindhu.TEST3_Sindhu;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Patient 
{
    public static void main( String[] args ){
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
    	Object o = ctx.getBean("patient");
    	PatientOps pop = (PatientOps)o;
    	pop.createTable();
    	Patient p = new Patient();
    	p.menuOptions();	
    }
    public void menuOptions() {
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
    	Object o = ctx.getBean("patient");
    	PatientOps pop = (PatientOps)o;
    	System.out.println("MENU:\n1.Insert: patientID,patientName,patientDisease\n2.Update: patientID,patientDisease\n3.Delete: patientID\n4.Select All\n5.Exit\nPlease select an Option(1/2/3/4/5):");
		Scanner sc = new Scanner(System.in);
		int temp=0;
		try{
			temp=sc.nextInt();
		} catch (InputMismatchException ie) {
			System.out.println("WARNING: Please enter valid choice!");
			menuOptions();
		}
		if(temp==1) {
			pop.insertPat();
		}
		if(temp==2) {
			pop.updatePat();
		}
		if(temp==3) {
			pop.deletePat();
		}
		if(temp==4) {
			pop.selectAll();
		}
		if(temp==5) {
			System.exit(0);
		}
		if(temp!=1 && temp!=2 && temp!=3 && temp!=4 && temp!=5) {
			System.out.println("WARNING: Please enter valid choice!");
			menuOptions();
		}
    }
}