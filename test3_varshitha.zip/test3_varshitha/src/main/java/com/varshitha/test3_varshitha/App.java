package com.varshitha.test3_varshitha;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * client program!
 *
 */
class Patient1{
	public static void patientRecords(ApplicationContext ctx) {
		Object o=ctx.getBean("pat1");
        Patient p=(Patient)o;
        System.out.println(p.patientId+"--"+p.patientName+"--"+p.patientDisease);
	}
	
}
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
    	Patient1.patientRecords(ctx);
    	
    	
    }
}