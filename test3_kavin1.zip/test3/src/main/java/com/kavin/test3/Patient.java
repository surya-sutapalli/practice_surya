package com.kavin.test3;



public class Patient {
	int patientId;
	String patientName;
	String patientDisease;
	
	Patient(int pId,String pName,String pDisease)
	{
		this.patientId=pId;
		this.patientName=pName;
		this.patientDisease=pDisease;
	}
	
	
	/*
	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientDisease() {
		return patientDisease;
	}

	public void setPatientDisease(String patientDisease) {
		this.patientDisease = patientDisease;
	}

	*/
	
	
	

	

}