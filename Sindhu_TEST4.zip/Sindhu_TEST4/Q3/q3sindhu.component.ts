import { Component, OnInit } from '@angular/core';
import {ifStmt} from "@angular/compiler/src/output/output_ast";

@Component({
  selector: 'app-q3sindhu',
  templateUrl: './q3sindhu.component.html',
  styleUrls: ['./q3sindhu.component.css']
})
export class Q3sindhuComponent{
  name:string="";
  display(name:string){
    this.name=name;
  }
}
