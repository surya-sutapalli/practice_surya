

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Question2Servlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
          
           ServletContext ctx= getServletContext();
           String d= ctx.getInitParameter("driver");
           String pId = request.getParameter("pid");
            String pName = request.getParameter("pname");
            String pAmount = request.getParameter("pamount");
            String pDuration = request.getParameter("pduration");
            Class.forName(d);
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/policy", "root","aditi");
            PreparedStatement pst=c.prepareStatement("insert into policyy values(?,?,?,?)");
            pst.setInt(1, Integer.parseInt(pId));
            pst.setString(2, pName);
            pst.setInt(3, Integer.parseInt(pAmount));
            pst.setString(4, pDuration);
            pst.execute();
            response.getWriter().println("<div align=center> Insert Sucessfully! </div>");

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}