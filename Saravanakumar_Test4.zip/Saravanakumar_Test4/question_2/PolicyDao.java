package com.saravana.HibernateWeb;


import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  

import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
public class PolicyDao {
	public void insert(String policyId,String policyName,String policyAmount,String policyDuration)
	{
	Configuration  cfg= new Configuration().configure("hibernate.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
    Session s= factory.openSession();
    Transaction t= s.beginTransaction();
    Policy obj=new Policy();
    obj.setPolicyId(Integer.parseInt(policyId));
    obj.setPolicyName(policyName);
    obj.setPolicyAmount(Integer.parseInt(policyAmount));
    obj.setPolicyDuration(Integer.parseInt(policyDuration));
    s.save(obj);
    t.commit();
    s.close();
    factory.close();
}
}
