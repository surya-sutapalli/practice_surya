package com.kaviya.Test3_kaviya2;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PatientClient {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory sf =cfg.buildSessionFactory();
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        System.out.println("Enter the Patient ID :::");
        int id=sc.nextInt();
        Object o=s.load(Patient.class, new Integer(id));
        Patient pt=(Patient)o;
        System.out.println(pt.getPatientID()+"...."+pt.getPatientName()+"...."+pt.getPatientDisease());
        s.close();
        sf.close();

    }

}
