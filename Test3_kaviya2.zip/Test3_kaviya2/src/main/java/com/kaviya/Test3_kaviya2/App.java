package com.kaviya.Test3_kaviya2;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Scanner sc=new Scanner(System.in);
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory sf =cfg.buildSessionFactory();
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Patient pt=new Patient();
        System.out.println("please Enter Patient ID::");
        int id=sc.nextInt();
        pt.setPatientID(id);
        System.out.println("Please Enter Patient Name::");
        String name=sc.next();
        pt.setPatientName(name);
        System.out.println("please Enter Patient Disease::");
        String disease=sc.next();
        pt.setPatientDisease(disease);
        s.save(pt);
        t.commit();
        PatientClient pc=new PatientClient();
        pc.main(null);
        sf.close();
        s.close();
        
    }
}
