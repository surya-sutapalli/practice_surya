package com.tharani.TEST3_Bavatharani;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class PatientClient {
	// method to insert data
	public void insertRecord(Session s,Transaction t,Patient p)
	{
		p.setPatientId(105);
		p.setPatientName("Arjun");
		p.setPatientDisease("Malaria");
		s.save(p);
        t.commit();
       System.out.println("Record Inserted");
	}
	// method to select data
	public void getDetails(Session s,Patient p,int pat_id)
	{   
		Object o=s.get(Patient.class,new Integer(pat_id));
		 Patient pat=(Patient)o;
		try
		{ System.out.println(pat.getPatientId()+"---"+pat.getPatientName()+"--- "+pat.getPatientDisease());
		}
		catch(NullPointerException e)
		{
			System.out.println("No Patient Found");
		}
	}
	// method to update data
	public void updateRecord(Session s,Transaction t,Patient p)
	{   
		 Object o=s.get(Patient.class,new Integer(101));
		  Patient pat=(Patient)o;
		  pat.setPatientName("Banu");
			pat.setPatientDisease("Fever");
			s.save(p);
	        t.commit();
	       System.out.println(" Record Updated");
	}
	// method to delete data
	public void deleteRecord(Session s,Transaction t,Patient p)
	{   
		Object o=s.get(Patient.class,new Integer(101));
		 Patient pat=(Patient)o;
			s.delete(pat);
	        t.commit();
	       System.out.println(" Record deleted");
	}
	// main method
	public static void main(String[] args) {
		Configuration  cfg= new Configuration();
		cfg.configure("hibernatePatient.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
        Session s= factory.openSession();
        Transaction t= s.beginTransaction();
        PatientClient obj= new PatientClient();
        Patient p= new Patient();
        //obj.insertRecord(s,t,p);
         obj.updateRecord(s,t,p);
         obj.deleteRecord(s,t,p);
        Scanner scan= new Scanner(System.in);
		while(true) 
		{
			System.out.println("Enter Patient Id to Get Details: ");
			int pat_id= scan.nextInt();
			obj.getDetails(s,p,pat_id);
			System.out.println("Do you want to continue? y/n");
			String val=scan.next();
			if(val.equalsIgnoreCase("y"))
			{continue;}
			else
			{System.out.println("Terminated Successfully");
			break;}
		}  
		scan.close();
		 s.close();
		 factory.close();
	}

}
