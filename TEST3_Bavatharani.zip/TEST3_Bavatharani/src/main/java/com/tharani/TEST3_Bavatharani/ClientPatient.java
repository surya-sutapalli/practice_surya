package com.tharani.TEST3_Bavatharani;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientPatient {
	public static void main(String[] args) {
	Configuration  cfg= new Configuration();
	cfg.configure("hibernatePatient.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
    Session s= factory.openSession();
    Transaction t= s.beginTransaction();
    PatientClient obj= new PatientClient();
    Patient p= new Patient();
    p.setPatientId(105);
	p.setPatientName("Arjun");
	p.setPatientDisease("Malaria");
	s.save(p);
    t.commit();
    Scanner scan= new Scanner(System.in);
    System.out.println("Enter Patient Id to Get Details: ");
	int pat_id= scan.nextInt();
    Object o=s.get(Patient.class,new Integer(pat_id));
	 Patient pat=(Patient)o;
	try
	{ System.out.println(pat.getPatientId()+"---"+pat.getPatientName()+"--- "+pat.getPatientDisease());
	}
	catch(NullPointerException e)
	{
		System.out.println("No Patient Found");
	}
	scan.close();
	 s.close();
	 factory.close();
}
}
