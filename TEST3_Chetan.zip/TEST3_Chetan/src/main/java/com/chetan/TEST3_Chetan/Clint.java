package com.chetan.TEST3_Chetan;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Clint 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx= new ClassPathXmlApplicationContext("config.xml");
    	Object o=ctx.getBean("obj");
    	Patient p =(Patient)o;
    	System.out.println(p.paitentID+"--"+p.paitentName+"--"+p.paitentDisease);
    	
    }
}
