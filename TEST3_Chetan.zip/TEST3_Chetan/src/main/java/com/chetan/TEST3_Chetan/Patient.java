package com.chetan.TEST3_Chetan;

public class Patient 
{
	int paitentID;
	String paitentName;
	String paitentDisease;
	
	Patient(int paitentID,String paitentName,String paitentDisease)
	{
		this.paitentID = paitentID;
		this.paitentName=paitentName;
		this.paitentDisease=paitentDisease;
		
		}

}
