package com.madhu.test3_Madhu2;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class DeletePatient {
  public static void delpat()
  {
    Scanner sc=new Scanner(System.in);
    System.out.println("Select id you want to delete");
    int n2=sc.nextInt();
    Configuration cfg=new Configuration();
    cfg.configure("hibernate.cfg.xml");
    SessionFactory sf=cfg.buildSessionFactory();
    Session s=sf.openSession();
    Transaction t=s.beginTransaction(); 
    Object o=s.get(Patient.class,new Integer(n2));
    Patient e=(Patient)o;
    s.delete(e);
    t.commit();
    s.close();
    sf.close();
  }
}