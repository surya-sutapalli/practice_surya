package com.madhu.test3_Madhu2;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class App 
{
    
      public static void main(String[] args) 
      {
        Scanner sc=new Scanner(System.in);
        System.out.println("Select options 1,2,3,4");
        int n=sc.nextInt();
        if(n==1)
        {
          System.out.println("insertion operation");
        InsertDetails.insertRecords();
        }
        else  if(n==2)
        {
          System.out.println("selection operation");
          SelectPatient.selpat();
        }
        else if(n==3)
        {
          System.out.println("deletion operation");
          DeletePatient.delpat(); 
        }
        else if(n==4)
        {
          System.out.println("update operation");
          UpdatePatient.updpat();
        }
        else
          System.out.println("invalid options");
        
}
}
