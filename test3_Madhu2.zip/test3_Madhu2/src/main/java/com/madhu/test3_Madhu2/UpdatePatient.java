package com.madhu.test3_Madhu2;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class UpdatePatient{
  public static void updpat()
  {
    Scanner sc=new Scanner(System.in);
    System.out.println("select id to update");
    int n3=sc.nextInt();
    Configuration cfg=new Configuration();
    cfg.configure("hibernate.cfg.xml");
    SessionFactory f=cfg.buildSessionFactory();
    Session s=f.openSession();
    Transaction t=s.beginTransaction();
    Object o=s.load(Patient.class,new Integer(n3));
    Patient e=(Patient)o;
    System.out.println(e.getId()+"--"+e.getPatientName()+"-- "+e.getPatientDisease());
    s.close();
    f.close();
    

  }

}

