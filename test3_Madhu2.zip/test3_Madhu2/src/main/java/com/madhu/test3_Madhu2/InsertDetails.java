package com.madhu.test3_Madhu2;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class InsertDetails {
  static final Patient obj = new Patient();
  static final Scanner scan = new Scanner(System.in);

  public static void insertRecords() {
    // Inserting Records
    Configuration cfg = new Configuration();
    cfg.configure("hibernate.cfg.xml");
    SessionFactory sf = cfg.buildSessionFactory();
    Session se = sf.openSession();
    Transaction t = se.beginTransaction();
    System.out.println("Enter ID");
    int id = scan.nextInt();
    obj.setId(id);
    System.out.println("Enter Name : ");
    String name = scan.next();
    obj.setPatientName(name);
    System.out.println("Enter Disease : ");
    String disease = scan.next();
    obj.setPatientDisease(disease);
    System.out.println("Inserted Successfully!!" + "\n" + "Displaying Inserted Record : ");
    System.out.println(
        obj.getId() + "------------->" + obj.getPatientName() + "-------------->" + obj.getPatientDisease());
    se.save(obj);
    t.commit();
    se.close();
    sf.close();
    App.main(null);
  }

}
