import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test10',
  templateUrl: './test10.component.html',
  styleUrls: ['./test10.component.css']
})
export class Test10Component {


  public name:string="";
  display(name:string) {
    this.name = name;
  }

}
