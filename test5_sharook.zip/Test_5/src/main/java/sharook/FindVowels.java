package sharook;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

public class FindVowels extends TagSupport {
	private String word;
	public void setWord(String word) {
		this.word = word.toLowerCase();
	}
	public int doStartTag() throws JspException {
		JspWriter out=pageContext.getOut();
		 String str = new String(this.word);
	      for(int i=0; i<str.length(); i++) {
	         if(str.charAt(i) == 'a'|| str.charAt(i) == 'e'|| str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u') {
	        	 try {
					out.println(str.charAt(i));
				} catch (IOException e) {
					e.printStackTrace();
				}
	         }
	         }
		return SKIP_BODY;
	}
}