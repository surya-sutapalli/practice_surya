

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class web1 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String st=request.getParameter("tf1");
			
			String op=request.getParameter("n1");
			if(op.equalsIgnoreCase("uc"))
			{
				response.getWriter().println("UpperCase:");
				
				for(int i=0;i<st.length();i++)
				{
					if(Character.isUpperCase(st.charAt(i)))
					{
						response.getWriter().println(st.charAt(i));
					}
			}
			}
			else if(op.equalsIgnoreCase("ucc"))
			{
				int c=0;
				response.getWriter().println("UpperCaseCount:");
				
				for(int i=0;i<st.length();i++)
				{
					if(Character.isLowerCase(st.charAt(i)))
					{
						c++;
					}
				
			}
				response.getWriter().println(c);
			}
			else if(op.equalsIgnoreCase("lc"))
			{
				response.getWriter().println("LowerCase:");
				
				for(int i=0;i<st.length();i++)
				{
					if(Character.isLowerCase(st.charAt(i)))
					{
						response.getWriter().println(st.charAt(i));
					}
			}
			}
			else if(op.equalsIgnoreCase("lcc"))
			{int c=0;
				response.getWriter().println("LowerCaseCount:");
				
				for(int i=0;i<st.length();i++)
				{
					if(Character.isLowerCase(st.charAt(i)))
					{
						c++;
					}
				
			}response.getWriter().println(c);
			}
			
			else if(op.equalsIgnoreCase("d"))
			{
				response.getWriter().println("Digits:");
				
				for(int i=0;i<st.length();i++)
				{
					if(Character.isDigit(st.charAt(i)))
					{
						response.getWriter().println(st.charAt(i));
					}
				}
			}
				else if(op.equalsIgnoreCase("dc"))
				{int c=0;
					response.getWriter().println("DigitsCount:");
					
					for(int i=0;i<st.length();i++)
					{
						if(Character.isDigit(st.charAt(i)))
						{
							c++;
						}
						}response.getWriter().println(c);
					
			}else
				if(op.equalsIgnoreCase("sc"))
				{
					response.getWriter().println("SpecialCharacter:");
					
					for(int i=0;i<st.length();i++)
					{
						if(!Character.isLetterOrDigit(st.charAt(i)))
						{
							response.getWriter().println(st.charAt(i));
						}
					}
				}else if(op.equalsIgnoreCase("scc"))
				{
					int c=0;
					response.getWriter().println("SpecialCharacterCount:");
					
					for(int i=0;i<st.length();i++)
					{
						if(!Character.isLetterOrDigit(st.charAt(i)))
						{
							c++;
						}
						}response.getWriter().println(c);
				}
			
				
			
		}catch(NumberFormatException e)
			{
				response.getWriter().println("Enter Valid Value");
			}
	

}}
