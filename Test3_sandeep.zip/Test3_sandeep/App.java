package com.sandeep.Test3_sandeep;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
        Object o=ctx.getBean("obj");
        Patient p=(Patient)o;
        System.out.println(p.patientID+"---"+p.patientName+"---"+p.patientDisease);
    }
}
