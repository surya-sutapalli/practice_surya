package com.sandeep.Test3_sandeep;

public class Patient {
	 int patientID;
	 String patientName;
	 String patientDisease;
	 
	 public Patient(int patientID,String patientName,String patientDisease) {
		 this.patientID=patientID;
		 this.patientName=patientName;
		 this.patientDisease=patientDisease;
	 }
}
