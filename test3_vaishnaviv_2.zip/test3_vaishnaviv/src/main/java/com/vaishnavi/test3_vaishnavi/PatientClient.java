package com.vaishnavi.test3_vaishnavi;

import java.util.Scanner;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class PatientClient {
	public void select(SessionFactory sf, Session s, Transaction t, Patient p,int id) {
		//int id=sc.nextInt();
		Object ob=s.load(Patient.class,new Integer(id));
		Patient pat=(Patient)ob;
		try {
		if(id==pat.getPatientId()){
			System.out.println(pat.getPatientId()+"--"+pat.getPatientName()+"--"+pat.getPatientDisease());
		}
		}
		catch( ObjectNotFoundException one)
		{
			System.out.println("No Patient found");
		}
		
	}

	public void delete(SessionFactory sf, Session s, Transaction t, Patient p,int id) {
		
		Object o1=s.load(Patient.class,new Integer(id));
		Patient pa=(Patient)o1;
		 s.delete(pa);
		
	}

	public void update(SessionFactory sf, Session s, Transaction t, Patient p,int id) {
		p.setPatientId(id);
		p.setPatientName("jerry");
	  p.setPatientDisease("fever");
	  s.update(p);
	}

	public void insert(SessionFactory sf, Session s, Transaction t, Patient p,int id) {
		p.setPatientId(id);
		p.setPatientName("jerry");
	  p.setPatientDisease("dengu");
	  s.save(p);
		
	}

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
	PatientClient pc=new PatientClient();
	Patient p=new Patient();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the patient Id");
	int id=sc.nextInt();
		//pc.insert(sf,s,t,p,id);
		//pc.update(sf,s,t,p,id);
		pc.delete(sf,s,t,p,id);
		//pc.select(sf,s,t,p,id);
		
		
		//p.setPatientId(105);
		//p.setPatientName("jack");
		//p.setPatientDisease("neck pain");
		
		
		

		//s.save(p);
		t.commit();
		s.close();
		sf.close();

	}

	

	
	

	

}
