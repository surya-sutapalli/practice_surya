package sharmi;

import java.util.Calendar;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
public class Vowel extends TagSupport {
	private String name;
	
	public void setname(String name)
	{
		this.name=name;
		
	}
	
	public int doStartTag() throws JspException
	{
		JspWriter out=pageContext.getOut();
		try {
			for (int i = 0; i < name.length(); i++)
			{ 
			
				char character=name.charAt(i);

		        if(character=='a' || character=='A' || character=='e' || character=='E' ||
		                character=='i' || character=='I' || character=='o' || character=='O' ||
		                character=='u' || character=='U')
		        {
		        	out.println(" "+character); 
		        }
			}
			

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return SKIP_BODY;
	}

}