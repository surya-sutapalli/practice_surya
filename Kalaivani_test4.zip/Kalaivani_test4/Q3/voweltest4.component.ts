import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voweltest4',
  templateUrl: './voweltest4.component.html',
  styleUrls: ['./voweltest4.component.css']
})
export class Voweltest4Component  {


  public name:string="";
  display(name:string) {
    this.name = name;
  }
}
