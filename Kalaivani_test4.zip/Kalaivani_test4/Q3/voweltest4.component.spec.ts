import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Voweltest4Component } from './voweltest4.component';

describe('Voweltest4Component', () => {
  let component: Voweltest4Component;
  let fixture: ComponentFixture<Voweltest4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Voweltest4Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Voweltest4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
