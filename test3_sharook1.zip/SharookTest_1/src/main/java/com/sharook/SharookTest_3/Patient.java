package com.sharook.SharookTest_3;

public class Patient {
	int PatientID;
	String PatientName;
	String PatientDisease;
	
	Patient(int PatientID, String PatientName, String PatientDisease){
		this.PatientID = PatientID;
		this.PatientName = PatientName;
		this.PatientDisease = PatientDisease;
	}

}
