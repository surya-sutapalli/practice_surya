package com.sharook.SharookTest_3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	
	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Config.xml");
		
		Object o = ctx.getBean("obj1");
		Patient p = (Patient)o;
		System.out.println(p.PatientID+"----"+p.PatientName+"---"+p.PatientDisease);
	}

}
