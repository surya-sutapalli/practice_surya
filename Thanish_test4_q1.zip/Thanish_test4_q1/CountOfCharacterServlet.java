
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CountOfCharacterServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str = request.getParameter("tf1");
		int u=0,l=0,d=0,s=0;
		for(int i=0;i<str.length();i++)
		{

			if(Character.isUpperCase(str.charAt(i)))
			{
				u++;   
			}
			else if(Character.isLowerCase(str.charAt(i)))
			{
				l++;
			}
			else if(Character.isDigit(str.charAt(i)))
			{
				d++;
			}
			else
			{
				s++;
			}
		}
		response.getWriter().println("<style>\r\n"
        + "body{\r\n"
        + "background-image:url(\"C:\\\\Users\\\\THANISH\\\\Downloads\\\\insert.jpg\");\r\n"
        + "background-repeat:no-repeat;\r\n"
        + "background-attachment: fixed;\r\n"
        + "background-size: 100% 100%;\r\n"
        + "\r\n"
        + "}\r\n"
        + "</style>");
		
		response.getWriter().println("In the string "+str+" there are <br>");
		response.getWriter().println(u+" Upper case letters, <br>");
		response.getWriter().println(l+" Lower case letters, </br>");
		response.getWriter().println(d+"  Digits and </br>");
		response.getWriter().println(s+" Special charcters ");
	


	}

}