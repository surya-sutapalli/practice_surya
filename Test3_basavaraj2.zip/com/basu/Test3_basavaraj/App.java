package com.basu.Test3_basavaraj;
import java.util.Scanner;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.basu.Test3_basavaraj.*;

public class App {

	public static void main(String[] args) {
		
		Configuration cfg=new Configuration();
		cfg.configure("Test3.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session =factory.openSession();
		Transaction t=session.beginTransaction();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the patient id to retrieve data");
		int ID=sc.nextInt();
		
	Object o=session.load(patient.class,new Integer(ID));
		patient pat=(patient)o;
		try {
			if(ID==pat.getPatientId()) {
				System.out.println(pat.getPatientId()+"-->"+pat.getPatientName()+"-->"+pat.getPatientDiesease());
			}
		}
		catch(ObjectNotFoundException one) {
			System.out.println("patient  not found");
		}
		t.commit();
		session.close();
		factory.close();
	}

}