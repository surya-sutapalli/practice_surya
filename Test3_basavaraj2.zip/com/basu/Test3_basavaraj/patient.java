package com.basu.Test3_basavaraj;

public class patient 
{
	int patientId;
	String patientName;
	String patientDiesease;
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientDiesease() {
		return patientDiesease;
	}
	public void setPatientDiesease(String patientDiesease) {
		this.patientDiesease = patientDiesease;
	}
	

}
