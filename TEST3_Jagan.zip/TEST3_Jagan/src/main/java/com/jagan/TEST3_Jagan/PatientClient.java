package com.jagan.TEST3_Jagan;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PatientClient {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("patient.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();

		Scanner scan = new Scanner(System.in);
		Patient patient = new Patient();
		PatientDao patientdao = new PatientDao();
		int option = 0;
		while(true){
			try {
				System.out.println("Enter 1 to Insert\n"
						+ "2 to Update\n"
						+ "3 to Delete");
				option = scan.nextInt();
				if(!(option>=1 && option<=3)) {
					System.out.println("Please Enter a valid option");					
					continue;
				}
			}
			catch(InputMismatchException iex) {
				System.err.println("Please select an valid option 1/2/3");
				scan.next();
				continue;
			}
			break;
		}
		if(option==1) {
			patientdao.insert(patient, session, trans, scan);
		}
		else if(option==2) {
			patientdao.update(patient,session,trans,scan);
		}
		else if(option==3) {
			patientdao.delete(patient,session,trans,scan);    
		}    
	}
}
