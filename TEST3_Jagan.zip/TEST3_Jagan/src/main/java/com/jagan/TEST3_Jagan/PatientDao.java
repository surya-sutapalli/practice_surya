package com.jagan.TEST3_Jagan;
import java.util.InputMismatchException;
import java.util.Scanner;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class PatientDao {
  public void insert(Patient patient,Session session,Transaction trans,Scanner scan) {    
    System.out.println("Enter patient name");
    String patientname = scan.next();
    System.out.println("Enter patient disease");
    String pdisease = scan.next();

    patient.setPatientName(patientname);    
    patient.setPatientDisease(pdisease);

    session.save(patient);
    trans.commit();
  }

  public void update(Patient patient, Session session, Transaction trans, Scanner scan) {
	  int patientid = 0;    
	    while(true){
	      try {
	        System.out.println("Enter the patient Id to make changes");
	        patientid = scan.nextInt();       
	        }      
	      catch(InputMismatchException iex) {
	        System.err.println("Please Enter valid option");
	        continue;
	      }
	      break;
	    }
	    System.out.println("Enter patient Disease");
	    String pdisease = scan.next();    

	    try {
	      Object o = session.load(Patient.class, new Integer(patientid));
	      Patient P1 = (Patient) o;      
	      P1.setPatientDisease(pdisease);
	      
	      session.update(P1);
	      trans.commit();
	      System.out.println("Updated Successfully");
	    }
	    catch(ObjectNotFoundException ex) {
	      System.out.println("No data found");
	    }	
  }

public void delete(Patient patient, Session session, Transaction trans, Scanner scan) {
		    int patientid;
		    while(true)
		    {
		      try {
		        System.out.println("Enter patient id to delete");
		        patientid = scan.nextInt();
		      }
		      catch(InputMismatchException iex) {
		        System.err.println("Please Enter valid Integer id");
		        continue;
		      }
		      break;
		    }    
		    try {
		    Patient P1 = (Patient) session.load(Patient.class, new Integer(patientid));
		    
		    session.delete(P1);
		    trans.commit();
		    System.out.println("The record of "+P1.getPatientId()+" deleted successfully");
		    }
		    catch(ObjectNotFoundException ex) {
		      System.out.println("Data not found");
		      System.out.println("Please visit again");
		    }
		  }
}



