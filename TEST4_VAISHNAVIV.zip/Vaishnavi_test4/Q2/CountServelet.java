

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CountServelet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String str=request.getParameter("String1");
		 int u=0;
	  	int l=0;
	  	int d=0,s=0;
	    for(int i=0;i<str.length();i++)
	    { 
	    	
	    	if(Character.isUpperCase(str.charAt(i)))
	    	{
	    		u++;
	    	}
	    	else if(Character.isLowerCase(str.charAt(i)))
	    	{
	    		l++;
	    	}
	    	else if(Character.isDigit(str.charAt(i)))
	    	{
	    		d++;
	    	}
	    	else
	    	{
	    		s++;
	    	}
	    	
	    }
	    response.getWriter().println("Number of UpperCase Letters :"+u+"<br>");
	    response.getWriter().println("Number of LowerCase Letters :"+l+"<br>");
	    response.getWriter().println("Number of Digits : " +d+"<br>");
	    response.getWriter().println("Number of SpecialCase Letters :"+s+"<br>");
	    
		
	}

}
