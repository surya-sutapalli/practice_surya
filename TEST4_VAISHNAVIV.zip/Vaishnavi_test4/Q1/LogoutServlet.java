

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LogoutServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession hs=request.getSession(true);
		hs.invalidate();
		//response.getWriter().println("<a href=http://localhost:8080/Test_4/Login.html>Back</a>");
		response.sendRedirect("http://localhost:8080/Test_4/Login.html");
	}

}
