

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class InsertServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			HttpSession hs=request.getSession();
			Object o=hs.getAttribute("LOGIN");
			String user=(String)o;
			response.getWriter().println("<div align=right>Logged in user:"+user+"</div>");
			response.getWriter().println("<div align=right><a href=http://localhost:8080/Test_4/LogoutServlet>SIGNOUT</a></div>");
			
			ServletContext  cxt=getServletContext();
			String d=cxt.getInitParameter("driver");
			String pId=request.getParameter("pid");
			String pName=request.getParameter("pname");
			String pAmount=request.getParameter("pamountl");
			String pDuration=request.getParameter("pduration");
			String sCity=request.getParameter("stcity");
			
			Class.forName(d);
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/hibernate","root","welcome");
			PreparedStatement pst=c.prepareStatement("insert into policy value(?,?,?,?)");
			pst.setInt(1, Integer.parseInt(pId));
			pst.setString(2, pName);
			pst.setString(3,pAmount);
			pst.setString(4,pDuration);
		
			pst.execute();
			/*response.getWriter().println(
					+ "     <script type=\"text/javascript\">\r\n"
					+ "     function msg()\r\n"
					+ "     {\r\n"
					+ "      alert(\"Inserted Successfully\");\r\n"
					+ "      }\r\n"
					+ "     </script>");*/
			
		} 
		catch (Exception e) {

			e.printStackTrace();
		}
	}

}
