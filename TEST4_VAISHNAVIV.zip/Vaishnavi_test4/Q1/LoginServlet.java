

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user=request.getParameter("uid");
		String pass=request.getParameter("upass");
		RequestDispatcher rd=null;
		HttpSession hs=request.getSession();
		if(user.equalsIgnoreCase(pass))
		{
			hs.setAttribute("LOGIN", user);
			rd=request.getRequestDispatcher("Insert.html");
			rd.forward(request, response);
		}
		else
		{
			response.getWriter().println("Invalid Login");
			rd=request.getRequestDispatcher("Login.html");
			rd.include(request, response);
		}
	}

}
