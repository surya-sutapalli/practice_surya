package com.nikita.Test3_Nikita;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
		Object o=ctx.getBean("obj1");
		Patient p=(Patient)o;
		System.out.println(p.patientId+p.patientName+p.patientDisease);
    }
}



	
	
		
		 
		
	