package com.nikita.Test3_Nikita;

public class Patient {
	int patientId;
	String patientName;
	String patientDisease;
	Patient(int patientId,String patientName,String patientDisease)
	{
		this.patientId=patientId;
		this.patientName=patientName;
		this.patientDisease=patientDisease;
	}

}
