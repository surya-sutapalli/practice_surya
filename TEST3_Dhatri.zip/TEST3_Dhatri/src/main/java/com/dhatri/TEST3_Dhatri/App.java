package com.dhatri.TEST3_Dhatri;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.dhatri.TEST3_Dhatri.Patient;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
Configuration cfg=new Configuration();
cfg.configure("hibernate.cfg.xml");
SessionFactory factory=cfg.buildSessionFactory();
Session session =factory.openSession();
Transaction t=session.beginTransaction();
Patient pat=new Patient();
pat.setPatientID(1);
pat.setPatientName("dhatri");
pat.setPatientDisease("fever");
session.save(pat);
t.commit();
session.close();
factory.close();
    }
}
