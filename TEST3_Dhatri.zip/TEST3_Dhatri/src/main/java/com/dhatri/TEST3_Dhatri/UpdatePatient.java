package com.dhatri.TEST3_Dhatri;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.dhatri.TEST3_Dhatri.Patient;

public class UpdatePatient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session =factory.openSession();
		Transaction t=session.beginTransaction();
		Object o=session.get(Patient.class,new Integer(1));
		Patient pat=(Patient)o;
	pat.setPatientName("dhatri");
	pat.setPatientDisease("cough");
		session.update(pat);
		t.commit();
		session.close();
		factory.close();

	}

}
