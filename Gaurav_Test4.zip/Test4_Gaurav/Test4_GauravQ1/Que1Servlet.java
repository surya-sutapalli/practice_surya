import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Que1Servlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String str=	request.getParameter("name");
		 int upp = 0, low = 0, numb = 0, special = 0;
	        for(int i = 0; i < str.length(); i++)
	        {
	            char ch = str.charAt(i);
	            if (ch >= 'A' && ch <= 'Z')
	                upp++;
	            else if (ch >= 'a' && ch <= 'z')
	                low++;
	            else if (ch >= '0' && ch <= '9')
	                numb++;
	            else
	                special++;
	        }
	
	        response.getWriter().print("<div id=con class=\"card text-black bg-success mb-3\">");
	        response.getWriter().println("Lower case letters : " + low+"<br>");
	        response.getWriter().println("Upper case letters : " + upp+"<br>");
	        response.getWriter().println("Number : " + numb+"<br>");
	        response.getWriter().println("Special characters : " + special+"<br>");
	        response.getWriter().print("</div>");
	}
	

	

}