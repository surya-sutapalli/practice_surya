import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class PolTableServlet extends HttpServlet {

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			Class.forName("com.mysql.jdbc.Driver");
		
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","gaurav");
		PreparedStatement pst=c.prepareStatement("Select * from policy");
		ResultSet rs=pst.executeQuery();
		response.getWriter().println("<table border=2 align=center bgcolor=Orange>"
		+"<thead>"
				+"<th>Policy ID</th><th>Policy-Name</th><th>Policy-Amount</th><th>Policy-Duration</th></thead>");
		while(rs.next())
		{
			response.getWriter().println("<tr>"+"<td>"+rs.getInt(1)+"</td>"+"<td>"+rs.getString(2)+"</td>"+"<td>"+rs.getString(3)+"</td>"+"<td>"+rs.getString(4)+"</td>"+"<tr>"+"<br>");
		}
	
		response.getWriter().println("</table>");
	}
		catch (Exception e) {
			e.printStackTrace();
		}}

}