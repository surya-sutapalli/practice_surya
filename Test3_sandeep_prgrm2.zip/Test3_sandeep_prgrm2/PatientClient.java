package com.sandeep.Test_sandeep;
import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PatientClient {

	public static void main(String[] args) {
		Configuration cfg=new Configuration().configure("hibernate.cfg.xml");
		SessionFactory f=cfg.buildSessionFactory();
		Session s=f.openSession();
		Transaction t=s.beginTransaction();
		Patienthib p=new Patienthib();
		System.out.println("enter options 1/2/3");
		Scanner sc=new Scanner(System.in);
		int z=sc.nextInt();
		switch(z) {
		case 1:
			p.setPatientID(4);
			p.setPatientName("p");
			p.setPatientDisease("fever");
			s.persist(p);
			break;
		case 2:
			Object o=s.get(Patienthib.class, new Integer(4));
			Patienthib ph=(Patienthib)o;
			ph.setPatientName("pq");
			s.update(ph);
			break;
		case 3:
			Object oo=s.get(Patienthib.class, new Integer(4));
			Patienthib ph1=(Patienthib)oo;
			s.delete(ph1);
		}
		t.commit();
		s.close();
		f.close();
	}

}
