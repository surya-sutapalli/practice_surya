package com.chandana.TEST3_CHANDANAP;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdatePatient {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session =factory.openSession();
		Transaction t=session.beginTransaction();
		Object o=session.get(Patient.class,new Integer(1));
		Patient pat=(Patient)o;
	    pat.setPatientID(1);
	    pat.setPatientName("chandana");
	    pat.setPatientDisease("virus");
		session.update(pat);
		t.commit();
		session.close();
		factory.close();
	}

}
