package com.thanish.test3_thanish;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class PatientClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cf=new Configuration();
		cf.configure("hibernate.cfg.xml");
		SessionFactory s=cf.buildSessionFactory();
		Session ses=s.openSession();
		Transaction t=ses.beginTransaction();
		Patient p = new Patient();
		System.out.println("Enter 1/2/3");
		Scanner sc = new Scanner(System.in);
		int op = sc.nextInt();

		if(op==1)
		{
			//p.setPatientId(101);
			//p.setPatientName("tia");
			//p.setPatientDisease("Cough");
			//p.setPatientId(102);
			//p.setPatientName("pia");
			//p.setPatientDisease("Cold");
			//p.setPatientId(103);
			//p.setPatientName("mia");
			//p.setPatientDisease("Fever");
			//p.setPatientId(104);
			//p.setPatientName("ria");
			//p.setPatientDisease("Headache");
			p.setPatientId(105);
			p.setPatientName("priya");
			p.setPatientDisease("Cough");
			ses.persist(p);
		}

		if(op==2)
		{
			Object o=ses.get(Patient.class,new Integer(105));
			Patient p1=(Patient)o;
			p1.setPatientDisease("Fever");
			ses.update(p1);
		}

		if(op==3)
		{
			Object o=ses.get(Patient.class,new Integer(105));
			Patient p2=(Patient)o;
			ses.delete(p2);
		}
		else
		{
			System.out.println("Enter correct option");
		}

		t.commit();
		ses.close();
		s.close();

	}

}