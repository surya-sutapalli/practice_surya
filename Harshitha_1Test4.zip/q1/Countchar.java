

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Countchar extends HttpServlet {


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();  
		response.setContentType("text/html");  
		out.println("<html><body>"); 

		int u=0,low=0,digit=0,sp=0;
		try
		{
			String name = request.getParameter("name1");
			int l=name.length();

			for(int i=0;i<l;i++)
			{
				if(Character.isUpperCase(name.charAt(i)))
				{
					u++;
				}
				else if(Character.isDigit(name.charAt(i)))
				{
					digit++;
				}
				else if(Character.isLowerCase(name.charAt(i)))
				{
					low++;
				}
				else
				{
					sp++;
				}
			}

		}
		catch(Exception e)
		{
			response.getWriter().println("inavlid input!/n please enter a valid string");
		}
		//response.getWriter().println("Upper case: "+u+"lowercase: "+low+"digits: "+digit+" special char:"+sp);

		 out.println("<table border=1 width=50% height=50% bgcolour=lightBlue align=center>");  
	        out.println("<head><title>Display Count</title></head>");

		out.println("<tbody>");
       // out.println("<tr><td>" + u + "</td><td>" + low + "</td><td>" + digit + "</td><td>" + sp + "</td></tr>");   

		out.println("<tr><td>uppercase:</td><td>"+u+"</td></tr><br>");
		out.println("<tr><td>lowercase:</td><td>"+low+"</td></tr><br>");
		out.println("<tr><td>digits:</td><td>"+digit+"</td></tr><br>");
		out.println("<tr><td>specialcharacters:</td><td>"+sp+"</td></tr><br>");
		out.println("out.println(\"</tbody><br>");
		out.println("</table>");
		 out.println("</table>");  
         out.println("</html></body>");  


	}


}


