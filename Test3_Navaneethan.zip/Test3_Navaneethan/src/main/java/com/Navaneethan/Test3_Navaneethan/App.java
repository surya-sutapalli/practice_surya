package com.Navaneethan.Test3_Navaneethan;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
    	 
        Country countryObj = (Country) ctx.getBean("CountryBean");
        String countryName=countryObj.getCountryName();
        String capitalName=countryObj.getCapital().getCapitalName();
        System.out.println(capitalName+" is capital of "+countryName);
       
    }
}
