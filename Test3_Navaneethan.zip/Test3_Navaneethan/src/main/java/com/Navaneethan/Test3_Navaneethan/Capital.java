package com.Navaneethan.Test3_Navaneethan;

public class Capital {
	 
    String capitalName;
 Capital(String capitalName)
 {
	 this.capitalName=capitalName;
 }
    public String getCapitalName() {
        return capitalName;
    }
 
    public void setCapitalName(String capitalName) {
        this.capitalName = capitalName;
    }
}
 