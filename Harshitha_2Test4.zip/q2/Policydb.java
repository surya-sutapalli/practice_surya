

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class Policydb extends HttpServlet {
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();  
        response.setContentType("text/html");  
        out.println("<html><body>");  
		try
		{
			//ServletConfig cfg=getServletConfig();
			//String d=cfg.getInitParameter("driver");
			ServletContext ctx=getServletContext();
			String d=ctx.getInitParameter("driver");
			
		String idd=request.getParameter("id");
		String nam=request.getParameter("name");
		String amountt=request.getParameter("amount");
		String dur=request.getParameter("duration");
		Class.forName(d);
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/policy","root","Harshitha@16");
		PreparedStatement pst=c.prepareStatement("insert into policy1 values(?,?,?,?)");
		pst.setInt(1,Integer.parseInt(idd));
		pst.setString(2,nam);
		pst.setInt(3,Integer.parseInt(amountt));
		pst.setString(4,dur);
		pst.execute();
		PreparedStatement pst1=c.prepareStatement("select * from policy1");
		ResultSet rs=pst1.executeQuery();
		 out.println("<table border=1 width=50% height=50% bgcolour=lightBlue>");  
         out.println("<tr><th>PolicyID</th><th>PolicyName</th><th>PolicyAmount</th><th>PolicyDuration</th><tr>");  
         while (rs.next()) 
         {  
             int n = rs.getInt("id");  
             String sn = rs.getString("name"); 
             int n2 =rs.getInt("amount");
             String sc = rs.getString("duration");   
             out.println("<tr><td>" + n + "</td><td>" + sn + "</td><td>" + n2 + "</td><td>" + sc + "</td></tr>");   
         }  
         out.println("</table>");  
         out.println("</html></body>");  
        c.close();
		}
		catch(Exception e)
		{
		e.printStackTrace();	
		}
		}

	
	
}
