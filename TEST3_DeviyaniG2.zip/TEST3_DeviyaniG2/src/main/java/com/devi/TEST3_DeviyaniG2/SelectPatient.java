package com.devi.TEST3_DeviyaniG2;

import java.util.Scanner;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.devi.TEST3_DeviyaniG2.Patient;


public class SelectPatient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session =factory.openSession();
		Transaction t=session.beginTransaction();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the patient id");
		int id=sc.nextInt();
		
	Object o=session.load(Patient.class,new Integer(id));
		Patient pat=(Patient)o;
		try {
			if(id==pat.getPatientID()) {
				System.out.println(pat.getPatientID()+"-->"+pat.getPatientName()+"-->"+pat.getPatientDisease());
			}
		}
		catch(ObjectNotFoundException one) {
			System.out.println("patient id not found");
		}
		t.commit();
		session.close();
		factory.close();
	}

}