package test;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CountServlet
 */
public class CountServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String str=request.getParameter("t1");
		char [] ch=str.toCharArray();
		int u=0,l=0,d=0,s=0;
		for(char c:ch) {
			if(Character.isUpperCase(c)) {
				u++;
			}
			else if(Character.isLowerCase(c)) {
				l++;
			}
			else if(Character.isDigit(c)) {
				d++;
		     }
		else {
			 s++;
		
		}   


	} 
		 
		
		response.getWriter().println("<style>\r\n"
			+ " .count{\r\n"
			+ "	 border: 1px solid black;\r\n"
			+ "   width: 200px;\r\n"
			+ "   margin: 5px ;\r\n"
			+ "   padding: 5px ;\r\n"
			+ "   display: inline-block;\r\n"
			+ "}"
			+ "</style>");
		response.getWriter().println("<style>\r\n"
			+ "body {\r\n"
			+ "  background-color: coral;\r\n"
			+ "}\r\n"
			+ "</style>");
		response.getWriter().println("<header>\r\n"
				+ "        <div align=\"center\">\r\n"
				+ "        <h1>Counting-Uppercase,Lowercase,Digits,Special charcters</h1>\r\n"
				+ "        </div>\r\n"
				+ "        <hr>\r\n"
				+ "</header>");
		
		response.getWriter().println("<br><br><br><br><div align=center>");
		response.getWriter().println("<div class=\"count\" >");
		response.getWriter().println("no of upper case: "+u+"<br>");
		response.getWriter().println("no of lower case: "+l+"<br>");
		response.getWriter().println("no of digits: "+d+"<br>");
		response.getWriter().println("no of special characters: "+s+"<br>");
		response.getWriter().println("<a href=http://localhost:8080/test/test1.html>Home</a>");
		response.getWriter().println("</div>");
		response.getWriter().println("</div>");
		

}


}