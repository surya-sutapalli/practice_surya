package test;

import java.io.IOException;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


/**
 * Servlet implementation class InsertServlet
 */
public class InsertServlet extends HttpServlet {
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		String pId=request.getParameter("tf1");
		String pName=request.getParameter("tf2");
		String pAmount=request.getParameter("tf3");
		String pDuration=request.getParameter("tf4");

		
		
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","welcome");
		PreparedStatement pst=c.prepareStatement("insert into policy1 values(?,?,?,?)");
		pst.setInt(1,Integer.parseInt(pId));
		pst.setString(2, pName);
		pst.setInt(3,Integer.parseInt(pAmount));
		pst.setInt(4,Integer.parseInt(pDuration));
		pst.execute();
		
			response.getWriter().println("<style>\r\n"
				+ "body {\r\n"
				+ "  background-color: lightblue;\r\n"
				+ "}\r\n"
				+ "</style>");
			response.getWriter().println("<br><br><br><br><body>\r\n"
					+ "        <div align=\"center\" >\r\n"
					+ "        <h1>Inserted Successfully!</h1>\r\n"
					+ "        </div>\r\n"
					+ "        \r\n"
					+ "</body>");
	}catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	
}
}