import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test8',
  templateUrl: './test8.component.html',
  styleUrls: ['./test8.component.css']
})
export class Test8Component  {
  public name:string="";
  display(name:string) {
    this.name = name;
  }
}
